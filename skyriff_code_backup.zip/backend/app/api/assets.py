"""
资产接口
"""
from fastapi import APIRouter, Depends, HTTPException, Query, UploadFile, File
from sqlalchemy.orm import Session
from app.db.database import get_db
from app.db.models import User
from app.schemas.assets import (
    VideoAssetResponse, DownloadUrlResponse, MediaUploadResponse,
    ProjectResponse, CreateProjectRequest, UpdateProjectRequest
)
from app.schemas.common import ResponseModel
from app.services.asset_service import AssetService
from app.api.dependencies import get_current_user
from typing import Optional
import uuid
import os

router = APIRouter(prefix="/api/v1/assets", tags=["资产"])


# ==================== 视频资产 ====================

@router.get("/videos", response_model=ResponseModel)
async def list_videos(
    project_id: Optional[int] = Query(None, description="项目ID过滤"),
    cursor: Optional[int] = Query(None, description="游标（video_id）"),
    limit: int = Query(20, ge=1, le=100, description="每页数量"),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    获取视频资产列表
    
    **需要登录**：是
    
    **功能**：
    - 返回用户生成的所有视频
    - 支持按项目过滤
    - 游标分页
    
    **响应示例**：
    ```json
    {
        "code": 200,
        "message": "success",
        "data": {
            "items": [
                {
                    "video_id": 5001,
                    "duration_sec": 10,
                    "ratio": "9:16",
                    "watermarked_play_url": "https://...",
                    "download_count": 2,
                    "created_at": "2025-12-25T10:00:00"
                }
            ],
            "has_more": false,
            "next_cursor": null
        }
    }
    ```
    """
    service = AssetService(db)
    
    videos = service.list_videos(
        user_id=current_user.user_id,
        project_id=project_id,
        limit=limit,
        cursor=cursor
    )
    
    items = [VideoAssetResponse.model_validate(video) for video in videos]
    has_more = len(items) == limit
    next_cursor = items[-1].video_id if has_more and items else None
    
    return ResponseModel(
        code=200,
        message="success",
        data={
            "items": items,
            "has_more": has_more,
            "next_cursor": next_cursor
        }
    )


@router.get("/videos/{video_id}", response_model=ResponseModel)
async def get_video(
    video_id: int,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    获取单个视频详情
    
    **需要登录**：是
    
    **权限**：只能查看自己的视频
    """
    service = AssetService(db)
    
    try:
        video = service.get_video(video_id, current_user.user_id)
        video_data = VideoAssetResponse.model_validate(video)
        
        return ResponseModel(code=200, message="success", data=video_data)
        
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))


@router.get("/videos/{video_id}/stream", response_model=None)
async def stream_video(
    video_id: int,
    token: Optional[str] = Query(None),
    current_user: User = Depends(get_current_user), # FastAPI 默认不支持 Query Token，需要自定义 Dependency 或 客户端 Header
    db: Session = Depends(get_db)
):
    """
    在线播放视频（通过后端代理或本地流）
    
    **需要登录**：是
    
    **功能**：
    - 如果视频已缓存到本地，直接返回本地文件流
    - 如果未缓存，通过后端代理流式传输，解决CORS和网络不稳定问题
    """
    service = AssetService(db)
    
    try:
        # 获取视频详情
        video = service.get_video(video_id, current_user.user_id)
        
        # 1. 检查是否是本地路径（以/static/开头）
        if video.watermarked_play_url and video.watermarked_play_url.startswith("/static/"):
            # 构造本地文件绝对路径
            # 假设 static 目录在项目根目录
            import os
            
            # URL: /static/videos/filename.mp4
            # Path: backend/static/videos/filename.mp4
            # 注意：backend 目录结构问题，需要小心处理
            # 假设 app.main 中 mount 的 static 目录是 backend/static
            
            # 从URL中提取相对路径
            rel_path = video.watermarked_play_url.lstrip("/")
            # 假设 backend 运行在 backend 目录下，或者项目根目录
            # 获取 backend 目录
            backend_dir = os.path.dirname(os.path.dirname(os.path.dirname(__file__)))
            file_path = os.path.join(backend_dir, rel_path)
            
            if os.path.exists(file_path):
                # 使用 FileResponse 以支持 Range 请求（视频拖拽）
                from fastapi.responses import FileResponse
                return FileResponse(file_path, media_type="video/mp4")
        
        # 2. 如果是远程URL，使用代理流
        video_url = video.watermarked_play_url
        if not video_url:
            raise ValueError("视频文件不可用")
            
        import httpx
        from fastapi.responses import StreamingResponse
        
        async def iter_file():
            async with httpx.AsyncClient() as client:
                async with client.stream("GET", video_url) as response:
                    # 不抛出错误，而是尝试传输
                    if response.status_code != 200:
                        # 如果远程失败，这里也无能为力，但可以记录日志
                        print(f"Proxy stream failed: {response.status_code}")
                        return 
                        
                    async for chunk in response.aiter_bytes():
                        yield chunk
                        
        return StreamingResponse(iter_file(), media_type="video/mp4")
        
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except Exception as e:
        print(f"Stream error: {e}")
        raise HTTPException(status_code=500, detail="播放服务暂时不可用")


@router.get("/videos/{video_id}/download", response_model=None)
async def download_video(
    video_id: int,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    下载视频（通过后端代理）
    
    **需要登录**：是
    
    **功能**：
    - 代理下载供应商视频，解决CORS和强制下载问题
    - 强制浏览器弹出下载框
    """
    service = AssetService(db)
    
    try:
        # 获取视频详情（鉴权）
        video = service.get_video(video_id, current_user.user_id)
        
        # 获取真实播放地址
        video_url = video.watermarked_play_url
        if not video_url:
            raise ValueError("视频文件不可用")
            
        # 使用HTTPClient流式传输
        import httpx
        from fastapi.responses import StreamingResponse
        
        async def iter_file():
            async with httpx.AsyncClient() as client:
                async with client.stream("GET", video_url) as response:
                    response.raise_for_status()
                    async for chunk in response.aiter_bytes():
                        yield chunk
                        
        filename = f"skyriff_video_{video_id}.mp4"
        
        return StreamingResponse(
            iter_file(),
            media_type="video/mp4",
            headers={"Content-Disposition": f'attachment; filename="{filename}"'}
        )
        
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except Exception as e:
        print(f"Download error: {e}")
        raise HTTPException(status_code=500, detail="下载服务暂时不可用")


# ==================== 媒体上传 ====================

@router.post("/media/upload", response_model=ResponseModel)
async def upload_media(
    file: UploadFile = File(...),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    上传媒体文件（图片）
    
    **需要登录**：是
    
    **支持格式**：jpg, jpeg, png, webp
    
    **最大大小**：10MB
    
    **用途**：图生视频的参考图
    
    **请求方式**：multipart/form-data
    
    **响应示例**：
    ```json
    {
        "code": 200,
        "message": "上传成功",
        "data": {
            "asset_id": 123,
            "asset_type": "image",
            "file_url": "https://storage.example.com/uploads/abc.jpg",
            "file_size_bytes": 102400,
            "width": 1024,
            "height": 768
        }
    }
    ```
    """
    # 校验文件类型
    allowed_types = ["image/jpeg", "image/jpg", "image/png", "image/webp"]
    if file.content_type not in allowed_types:
        raise HTTPException(status_code=400, detail="不支持的文件格式")
    
    # 读取文件
    content = await file.read()
    file_size = len(content)
    
    # 校验文件大小（10MB）
    if file_size > 10 * 1024 * 1024:
        raise HTTPException(status_code=400, detail="文件过大，最大10MB")
    
    # 生成唯一文件名
    ext = os.path.splitext(file.filename)[1]
    filename = f"{uuid.uuid4()}{ext}"
    
    # 保存文件（简化版：本地存储）
    # TODO: 生产环境应使用OSS（阿里云/腾讯云）
    from app.core.config import settings
    upload_dir = settings.UPLOAD_DIR
    os.makedirs(upload_dir, exist_ok=True)
    
    file_path = os.path.join(upload_dir, filename)
    with open(file_path, "wb") as f:
        f.write(content)
    
    # 生成文件URL（简化版：相对路径）
    # TODO: 生产环境应返回CDN URL
    file_url = f"/uploads/{filename}"
    
    # 获取图片尺寸（简化版：跳过）
    # TODO: 使用PIL获取真实尺寸
    width = None
    height = None
    
    # 创建媒体资产记录
    service = AssetService(db)
    media = service.create_media_asset(
        user_id=current_user.user_id,
        asset_type="image",
        file_url=file_url,
        file_size_bytes=file_size,
        mime_type=file.content_type,
        width=width,
        height=height
    )
    
    return ResponseModel(
        code=200,
        message="上传成功",
        data=MediaUploadResponse(
            asset_id=media.asset_id,
            asset_type=media.asset_type,
            file_url=media.file_url,
            file_size_bytes=media.file_size_bytes,
            width=media.width,
            height=media.height,
            created_at=media.created_at
        )
    )


# ==================== 项目管理 ====================

@router.get("/projects", response_model=ResponseModel)
async def list_projects(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    获取项目列表
    
    **需要登录**：是
    
    **响应示例**：
    ```json
    {
        "code": 200,
        "message": "success",
        "data": [
            {
                "project_id": 1,
                "name": "我的第一个项目",
                "video_count": 5,
                "created_at": "2025-12-25T10:00:00"
            }
        ]
    }
    ```
    """
    service = AssetService(db)
    projects = service.list_projects(current_user.user_id)
    
    items = [ProjectResponse.model_validate(p) for p in projects]
    
    return ResponseModel(code=200, message="success", data=items)


@router.post("/projects", response_model=ResponseModel)
async def create_project(
    req: CreateProjectRequest,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    创建项目
    
    **需要登录**：是
    
    **请求示例**：
    ```json
    {
        "name": "我的第一个项目",
        "description": "用于存放测试视频"
    }
    ```
    """
    service = AssetService(db)
    
    project = service.create_project(
        user_id=current_user.user_id,
        name=req.name,
        description=req.description
    )
    
    project_data = ProjectResponse.model_validate(project)
    
    return ResponseModel(code=200, message="创建成功", data=project_data)


@router.patch("/projects/{project_id}", response_model=ResponseModel)
async def update_project(
    project_id: int,
    req: UpdateProjectRequest,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    更新项目
    
    **需要登录**：是
    """
    service = AssetService(db)
    
    try:
        project = service.update_project(
            project_id=project_id,
            user_id=current_user.user_id,
            name=req.name,
            description=req.description
        )
        
        project_data = ProjectResponse.model_validate(project)
        
        return ResponseModel(code=200, message="更新成功", data=project_data)
        
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))


@router.delete("/projects/{project_id}", response_model=ResponseModel)
async def delete_project(
    project_id: int,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    删除项目
    
    **需要登录**：是
    
    **注意**：只删除项目，不删除视频（视频会解除关联）
    """
    service = AssetService(db)
    
    try:
        service.delete_project(project_id, current_user.user_id)
        
        return ResponseModel(code=200, message="删除成功", data=None)
        
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))
