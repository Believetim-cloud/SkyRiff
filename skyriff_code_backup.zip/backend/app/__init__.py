"""
SkyRiff 后端应用
"""
__version__ = "1.0.0"
