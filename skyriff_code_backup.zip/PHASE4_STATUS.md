# 🚧 SkyRiff Phase 4 开发状态

> **状态**：进行中  
> **完成度**：数据库模型已补充，待开发API接口  
> **当前日期**：2025-12-25

---

## 📊 Phase 4 目标

### 核心功能模块
1. ✅ **数据库模型**：已在models.py中定义（8张新表）
2. 🔄 **支付系统**：模拟支付充值（待开发API）
3. 🔄 **月卡系统**：购买月卡+每日领取（待开发API）
4. 🔄 **任务中心**：每日任务+领取奖励（待开发API）
5. 🔄 **排行榜**：创作者打赏排行（待开发API）
6. 🔄 **金币提现**：创作者收益提现（待开发API）

---

## ✅ 已完成工作

### 1. 数据库模型补充

已在 `/backend/app/db/models.py` 中新增以下表：

#### Phase 4 新增表（8张）

| 表名 | 说明 | 状态 |
|------|------|------|
| `payments` | 支付单表 | ✅ 已定义 |
| `subscriptions` | 月卡订阅表 | ✅ 已定义 |
| `daily_reward_claims` | 每日领取记录表 | ✅ 已定义 |
| `task_definitions` | 任务定义表（系统配置） | ✅ 已定义 |
| `daily_task_assignments` | 每日任务分配表 | ✅ 已定义 |
| `withdrawals` | 提现单表 | ✅ 已定义 |
| `referral_codes` | 推广码表 | ✅ 已定义（推广员系统） |
| `referral_bindings` | 邀请绑定表 | ✅ 已定义（推广员系统） |

**注意**：部分表在"财务体系"和"推广员系统"部分已提前定义。

### 2. 初始化脚本

创建了 `/backend/scripts/init_phase4_data.py`：
- ✅ 任务定义初始化（6个任务）
- ✅ 商品数据初始化（4个充值档位 + 1个月卡）

---

## 🔄 待开发工作

### 1. Schema层（Pydantic模型）

需要创建：
- `app/schemas/payments.py` - 支付相关Schema
- `app/schemas/subscriptions.py` - 月卡相关Schema
- `app/schemas/tasks_center.py` - 任务中心Schema
- `app/schemas/withdrawals.py` - 提现相关Schema

### 2. 服务层（业务逻辑）

需要创建：
- `app/services/payment_service.py` - 支付服务
- `app/services/subscription_service.py` - 月卡服务
- `app/services/task_center_service.py` - 任务中心服务
- `app/services/withdrawal_service.py` - 提现服务

### 3. API路由层

需要创建：
- `app/api/payments.py` - 支付接口
- `app/api/subscriptions.py` - 月卡接口
- `app/api/tasks_center.py` - 任务中心接口
- `app/api/withdrawals.py` - 提现接口
- `app/api/rankings.py` - 排行榜接口

---

## 📋 API接口规划

### 支付系统（5个接口）

| 接口 | 方法 | 描述 |
|------|------|------|
| `/api/v1/products` | GET | 获取商品列表（充值档位/月卡） |
| `/api/v1/payments/create` | POST | 创建支付单（模拟支付） |
| `/api/v1/payments/{id}` | GET | 查询支付状态 |
| `/api/v1/payments/callback` | POST | 支付回调（模拟）|
| `/api/v1/payments/history` | GET | 支付历史 |

### 月卡系统（3个接口）

| 接口 | 方法 | 描述 |
|------|------|------|
| `/api/v1/subscriptions/buy` | POST | 购买月卡 |
| `/api/v1/subscriptions/me` | GET | 查询我的月卡状态 |
| `/api/v1/subscriptions/claim_daily` | POST | 每日领取积分 |

### 任务中心（3个接口）

| 接口 | 方法 | 描述 |
|------|------|------|
| `/api/v1/tasks_center/today` | GET | 今日任务列表 |
| `/api/v1/tasks_center/{task_key}/claim` | POST | 领取任务奖励 |
| `/api/v1/tasks_center/assign_daily` | POST | 分配每日任务（系统调用） |

### 提现系统（4个接口）

| 接口 | 方法 | 描述 |
|------|------|------|
| `/api/v1/withdrawals/create` | POST | 创建提现申请 |
| `/api/v1/withdrawals/me` | GET | 我的提现记录 |
| `/api/v1/withdrawals/{id}` | GET | 查询提现详情 |
| `/api/v1/withdrawals/{id}/process` | PUT | 处理提现（管理员） |

### 排行榜（1个接口）

| 接口 | 方法 | 描述 |
|------|------|------|
| `/api/v1/rankings/creators/tips` | GET | 创作者打赏排行榜 |

---

## 🎯 核心业务流程设计

### 1. 模拟支付充值流程

```python
# 用户操作
POST /api/v1/payments/create
{
  "product_id": 1,  # 100积分 - 6元
  "pay_channel": "mock"  # 模拟支付
}

# 后端流程
1. 创建支付单（status=pending）
2. 模拟支付（自动成功）:
   - 更新支付单状态：success
   - 发放积分：wallet.balance += 100
   - 记录流水：ledger.create(type="recharge", amount=+100)
3. 返回支付结果
```

### 2. 月卡每日领取流程

```python
# 用户操作
POST /api/v1/subscriptions/claim_daily

# 后端流程
1. 检查是否有active的subscription
2. 检查今天是否已领取
3. 发放30积分：
   - wallet.balance += 30
   - ledger.create(type="subscription_daily_bonus", amount=+30)
   - DailyRewardClaim.create(user_id, today, 30)
4. 返回成功
```

### 3. 每日任务流程

```python
# 系统每天0点执行
POST /api/v1/tasks_center/assign_daily
1. 为所有用户分配3个任务：
   - 1个活跃类（login_daily固定）
   - 1个创作类（gen_success/publish_work随机）
   - 1个互动类（like_work/follow_user随机）

# 用户登录时自动完成"每日登录"任务
if task = get_today_task("login_daily"):
    task.status = "completed"
    task.completed_at = now()

# 用户手动领取奖励
POST /api/v1/tasks_center/login_daily/claim
1. 检查任务状态：must be "completed"
2. 发放2积分
3. 更新任务状态：status="claimed"
```

---

## 💡 开发建议

### 简化版Phase 4（快速上线）

由于Phase 4功能较多，建议分步实施：

#### 阶段1：核心充值功能（优先）
- ✅ 商品列表
- ✅ 模拟支付充值
- ✅ 支付历史

#### 阶段2：月卡系统
- ✅ 购买月卡
- ✅ 每日领取

#### 阶段3：任务中心
- ✅ 今日任务
- ✅ 领取奖励

#### 阶段4：排行榜+提现
- ✅ 创作者排行榜
- ✅ 金币提现

---

## 🔧 当前技术栈

### 已集成
- FastAPI（Web框架）
- SQLAlchemy（ORM）
- Pydantic（数据验证）
- PostgreSQL（数据库）
- JWT认证（用户登录）

### Phase 4新增需求
- 支付模拟逻辑（不对接真实支付网关）
- 定时任务系统（可选：Celery或APScheduler）

---

## 📝 代码规范

### 文件组织

```
backend/
├── app/
│   ├── schemas/
│   │   ├── payments.py          # Phase 4新增
│   │   ├── subscriptions.py     # Phase 4新增
│   │   ├── tasks_center.py      # Phase 4新增
│   │   └── withdrawals.py       # Phase 4新增
│   ├── services/
│   │   ├── payment_service.py   # Phase 4新增
│   │   ├── subscription_service.py  # Phase 4新增
│   │   ├── task_center_service.py   # Phase 4新增
│   │   └── withdrawal_service.py    # Phase 4新增
│   └── api/
│       ├── payments.py          # Phase 4新增
│       ├── subscriptions.py     # Phase 4新增
│       ├── tasks_center.py      # Phase 4新增
│       ├── withdrawals.py       # Phase 4新增
│       └── rankings.py          # Phase 4新增
└── scripts/
    └── init_phase4_data.py      # ✅ 已创建
```

---

## 🎉 Phase 4完成后的里程碑

完成Phase 4后，SkyRiff将拥有：

- ✅ **36张数据库表**（28张现有 + 8张新增）
- ✅ **70+个API接口**（53个现有 + 17个新增）
- ✅ **完整的商业闭环**：
  - 用户充值 → 生成视频 → 发布作品 → 获得打赏 → 提现收益
- ✅ **激励系统**：
  - 月卡每日领取
  - 每日任务奖励
  - 创作者排行榜

---

## 🚀 下一步行动

### 立即可做
1. 运行初始化脚本：
   ```bash
   cd backend
   python scripts/init_phase4_data.py
   ```

2. 创建Schema层（payments.py等）

3. 创建服务层（payment_service.py等）

4. 创建API路由层（payments.py等）

5. 测试充值流程

---

**更新时间**：2025-12-25  
**文档状态**：进行中  
**完成度**：20%（数据库模型已完成）

---

**下一份文档**：完成Phase 4开发后，创建 `/PHASE4_COMPLETE.md`
