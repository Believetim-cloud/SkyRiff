# 📖 SkyRiff API 详细使用指南

## 🎯 完整功能演示

本指南详细说明如何使用SkyRiff的4大核心功能。

---

## 1️⃣ 生成AI视频 🎬

### 功能说明
通过文字描述生成精彩的AI视频，无需任何图片素材。

### 使用步骤

#### 方式A: 通过视频工作室
```
1. 点击底部导航中间的"工作室"按钮（视频图标）
   ↓
2. 点击"🎬 生成AI视频"卡片
   ↓
3. 在弹出的对话框中：
   - 确保选择"文生视频"模式
   - 输入提示词（例如：可爱的狗 开飞机）
   - 选择模型（推荐：竖屏 15秒）
   ↓
4. 点击"开始生成"按钮
   ↓
5. 等待进度完成（3-5分钟）
   ↓
6. 自动跳转到资产页查看结果
```

### API调用示例

**JavaScript/TypeScript**:
```typescript
import { generateVideoFromText } from './services/sora-api';

// 生成视频
const result = await generateVideoFromText(
  '可爱的狗 开飞机',           // 提示词
  'sora2-portrait-15s',         // 模型
  (task) => {
    // 进度回调
    console.log(`进度: ${task.progress}%`);
    console.log(`状态: ${task.status}`);
    
    if (task.status === 'success') {
      console.log('视频URL:', task.video_url);
    }
  }
);

if (result.success) {
  console.log('生成成功!');
  console.log('视频ID:', result.data.id);
  console.log('视频URL:', result.data.video_url);
} else {
  console.error('生成失败:', result.error?.message);
}
```

**Python**:
```python
import requests
import time

# 配置
API_KEY = "YOUR_API_KEY"
BASE_URL = "http://prod-cn.your-api-server.com"

# 步骤1: 创建视频生成任务
def create_video_task(prompt, model):
    url = f"{BASE_URL}/v1/videos"
    headers = {
        "Authorization": f"Bearer {API_KEY}",
        "Content-Type": "application/json"
    }
    data = {
        "prompt": prompt,
        "model": model
    }
    
    response = requests.post(url, json=data, headers=headers)
    return response.json()

# 步骤2: 查询任务状态
def check_status(video_id):
    url = f"{BASE_URL}/v1/videos/{video_id}"
    headers = {
        "Authorization": f"Bearer {API_KEY}"
    }
    
    response = requests.get(url, headers=headers)
    return response.json()

# 步骤3: 轮询直到完成
def wait_for_completion(video_id):
    while True:
        status = check_status(video_id)
        progress = status.get('progress', 0)
        
        print(f"进度: {progress}%")
        
        if status.get('status') == 'success':
            return status.get('video_url')
        
        if status.get('status') == 'failed':
            raise Exception('生成失败')
        
        time.sleep(5)  # 等待5秒

# 完整流程
task = create_video_task('可爱的狗 开飞机', 'sora2-portrait-15s')
video_id = task['id']
print(f"任务ID: {video_id}")

video_url = wait_for_completion(video_id)
print(f"视频URL: {video_url}")
```

### 推荐提示词模板

**自然风景**:
```
- "金色日落下的海浪拍打沙滩，海鸥飞过"
- "森林中的小溪流水，阳光透过树叶"
- "雪山之巅的云海翻涌，壮丽景象"
- "樱花树下的花瓣飘落，春日美景"
```

**城市场景**:
```
- "繁华都市的霓虹灯光，车流穿梭"
- "现代化城市天际线，日落时分"
- "雨夜街道的倒影，行人匆匆"
- "咖啡店窗外的街景，温馨氛围"
```

**科幻创意**:
```
- "宇宙中的星球旋转，星云闪耀"
- "未来科技城市，飞行器穿梭"
- "赛博朋克风格街道，霓虹灯光"
- "太空站外的地球视角，宇航员漂浮"
```

**动物主题**:
```
- "可爱的猫咪在阳光下打哈欠"
- "蝴蝶在花丛中飞舞，色彩斑斓"
- "小鸟在树枝上跳跃，欢快鸣叫"
- "海豚在海面跃出水面，优雅姿态"
```

---

## 2️⃣ 图片转视频 📸

### 功能说明
上传静态图片，AI让画面动起来，添加动态效果。

### 使用步骤

#### 方式A: 通过视频工作室
```
1. 点击底部导航"工作室"
   ↓
2. 点击"📸 图片转视频"卡片
   ↓
3. 在弹出的对话框中：
   - 自动选择"图生视频"模式
   - 点击"选择图片文件"上传图片
   或
   - 输入图片URL
   ↓
4. 输入提示词（例如：让画面动起来，添加飘落的樱花）
   ↓
5. 选择模型
   ↓
6. 点击"开始生成"
   ↓
7. 等待完成
```

#### 方式B: 通过创作页
```
1. 点击底部"创作"Tab
   ↓
2. 点击图片图标上传图片
   ↓
3. 输入提示词
   ↓
4. 点击底部向上箭头
   ↓
5. 在弹窗中选择模型并生成
```

### API调用示例

**上传文件方式**:
```typescript
import { generateVideoFromImageFile } from './services/sora-api';

// 从文件输入获取文件
const fileInput = document.querySelector('input[type="file"]');
const file = fileInput.files[0];

// 生成视频
const result = await generateVideoFromImageFile(
  file,                           // 图片文件
  '让画面动起来，添加飘落的樱花',  // 提示词
  'sora2-portrait-15s',           // 模型
  (task) => {
    console.log(`进度: ${task.progress}%`);
  }
);

if (result.success) {
  console.log('生成成功!');
  console.log('视频URL:', result.data.video_url);
}
```

**URL方式**:
```typescript
import { generateVideoFromImageUrl } from './services/sora-api';

const result = await generateVideoFromImageUrl(
  'https://example.com/my-image.jpg',  // 图片URL
  '改成电影风格，添加光效',            // 提示词
  'sora2-portrait-15s',                // 模型
  (task) => {
    console.log(`进度: ${task.progress}%`);
  }
);
```

**Python - 文件上传**:
```python
import requests

API_KEY = "YOUR_API_KEY"
BASE_URL = "http://prod-cn.your-api-server.com"

def upload_image_to_video(image_path, prompt, model):
    url = f"{BASE_URL}/v1/videos"
    headers = {
        "Authorization": f"Bearer {API_KEY}"
    }
    
    files = {
        'input_reference': open(image_path, 'rb')
    }
    
    data = {
        'prompt': prompt,
        'model': model
    }
    
    response = requests.post(url, headers=headers, files=files, data=data)
    return response.json()

# 使用示例
task = upload_image_to_video(
    'my-photo.jpg',
    '让画面动起来，添加飘落的樱花',
    'sora2-portrait-15s'
)

print(f"任务ID: {task['id']}")
```

### 提示词技巧

**让画面动起来**:
```
- "让画面动起来"
- "添加动态效果"
- "画面流动起来"
- "创造运动感"
```

**添加特效**:
```
- "添加飘落的花瓣"
- "添加粒子特效"
- "添加光影效果"
- "添加下雨效果"
```

**风格转换**:
```
- "改成电影风格"
- "变成动画风格"
- "转换为水彩画风格"
- "改成复古胶片风格"
```

**增强效果**:
```
- "增强光影对比"
- "添加景深效果"
- "增加色彩饱和度"
- "添加镜头光晕"
```

---

## 3️⃣ 管理视频资产 📁

### 功能说明
查看、管理和下载所有生成的视频，实时查看生成进度。

### 使用步骤

#### 方式A: 通过视频工作室
```
1. 点击"工作室"
   ↓
2. 点击"📁 管理视频资产"卡片
   ↓
3. 查看所有视频列表
   - 生成中的视频：显示进度条
   - 已完成的视频：点击播放
   - 失败的视频：显示错误状态
   ↓
4. 点击右上角"刷新"按钮手动更新
```

#### 方式B: 直接访问资产页
```
1. 点击底部"资产"Tab
   ↓
2. 自动加载所有视频
   ↓
3. 每5秒自动刷新进行中的任务
```

### 功能特性

**自动刷新**:
- 每5秒自动查询进行中任务的状态
- 实时更新进度条
- 完成后自动更新状态

**视频操作**:
- 点击视频：在新标签页打开播放
- 右键复制链接：获取视频URL
- 查看详情：时长、创建时间等

**筛选功能**:
- 按状态筛选（全部/生成中/已完成/失败）
- 按项目分类
- 按时间排序

### API调用示例

**查询单个视频状态**:
```typescript
import { getVideoStatus } from './services/sora-api';

const result = await getVideoStatus('video_xxx');

if (result.success) {
  const task = result.data;
  console.log('状态:', task.status);
  console.log('进度:', task.progress + '%');
  
  if (task.status === 'success') {
    console.log('视频URL:', task.video_url);
  }
}
```

**批量查询多个视频**:
```typescript
import { getVideoStatus } from './services/sora-api';

const videoIds = ['video_1', 'video_2', 'video_3'];

const results = await Promise.all(
  videoIds.map(id => getVideoStatus(id))
);

results.forEach((result, index) => {
  if (result.success) {
    console.log(`视频${index + 1}:`, result.data.status);
  }
});
```

**本地存储操作**:
```typescript
import {
  getLocalVideos,
  getProcessingVideos,
  getCompletedVideos,
  deleteLocalVideo
} from './services/storage';

// 获取所有视频
const allVideos = getLocalVideos();
console.log('总共有', allVideos.length, '个视频');

// 获取进行中的视频
const processing = getProcessingVideos();
console.log('正在生成', processing.length, '个视频');

// 获取已完成的视频
const completed = getCompletedVideos();
console.log('已完成', completed.length, '个视频');

// 删除视频
deleteLocalVideo('video_xxx');
```

---

## 4️⃣ 创作精彩作品 ✨

### 功能说明
灵感画廊，提供创意模板和专业技巧，帮助您创作专业级作品。

### 使用步骤

```
1. 点击"工作室"
   ↓
2. 点击"✨ 创作精彩作品"卡片
   ↓
3. 浏览灵感画廊
   - 查看创意示例
   - 点击任意示例使用提示词
   ↓
4. 点击"开始新的创作"
   ↓
5. 自动跳转到视频生成器
```

### 专业技巧

#### 提示词编写技巧

**结构化提示词**:
```
[主体] + [动作] + [环境] + [氛围] + [风格]

示例：
"一只金色的狐狸 / 在森林中奔跑 / 阳光透过树叶 / 梦幻氛围 / 电影级画质"
```

**详细描述**:
```
❌ 不好: "一只狗"
✅ 好: "一只金毛犬在草地上欢快地奔跑，阳光洒在毛发上"

❌ 不好: "城市"
✅ 好: "繁华的现代都市夜景，霓虹灯闪烁，车流穿梭在街道上"
```

#### 模型选择策略

**快速预览** (10秒模型):
```
适用场景：
- 测试提示词效果
- 快速预览创意
- 生成大量素材

推荐模型：
- sora2-portrait (竖屏)
- sora2-landscape (横屏)
```

**日常创作** (15秒标准):
```
适用场景：
- 社交媒体发布
- 日常视频制作
- 质量和速度平衡

推荐模型：
- sora2-portrait-15s (竖屏)
- sora2-landscape-15s (横屏)
```

**专业创作** (Pro模型):
```
适用场景：
- 商业项目
- 高质量作品
- 重要发布

推荐模型：
- sora2-pro-portrait-25s (25秒)
- sora2-pro-portrait-hd-15s (15秒高清)
```

### 创作工作流程

**标准工作流程**:
```
1. 构思创意
   ↓
2. 编写详细提示词
   ↓
3. 使用10秒模型快速预览
   ↓
4. 根据效果调整提示词
   ↓
5. 使用15秒或Pro模型生成最终版本
   ↓
6. 导出和发布
```

**批量创作流程**:
```
1. 准备多个提示词
   ↓
2. 同时提交多个任务
   ↓
3. 在资产页统一管理
   ↓
4. 完成后批量下载
```

---

## 📊 完整使用流程示例

### 场景1: 从零开始创作一个视频

```
1. 打开APP
   ↓
2. 点击底部中间"工作室"按钮
   ↓
3. 阅读快速统计信息
   - 8个可用模型
   - 当前生成的视频数
   ↓
4. 点击"🎬 生成AI视频"
   ↓
5. 输入提示词：
   "金色日落下的海浪拍打沙滩，海鸥飞过天空，温暖的光线"
   ↓
6. 选择模型："竖屏 15秒"
   ↓
7. 点击"开始生成"
   ↓
8. 观察进度条（0% → 100%）
   预计等待：3-5分钟
   ↓
9. 生成成功，自动跳转到资产页
   ↓
10. 点击视频卡片播放
    ↓
11. 满意后可以分享或下载
```

### 场景2: 上传图片制作视频

```
1. 准备一张图片（风景照片）
   ↓
2. 打开"工作室" → "📸 图片转视频"
   ↓
3. 点击"选择图片文件"，上传照片
   ↓
4. 输入提示词：
   "让画面动起来，添加飘落的花瓣，增强光影效果"
   ↓
5. 选择"竖屏 15秒"模型
   ↓
6. 点击"开始生成"
   ↓
7. 等待完成（3-5分钟）
   ↓
8. 查看效果
   ↓
9. 如果满意，下载视频
   ↓
10. 如果不满意，调整提示词重新生成
```

### 场景3: 批量创作多个视频

```
1. 准备5个不同的提示词
   ↓
2. 依次提交生成任务：
   - 任务1: "森林小溪"
   - 任务2: "城市夜景"
   - 任务3: "星空银河"
   - 任务4: "海浪日落"
   - 任务5: "雪山云海"
   ↓
3. 前往"资产"页面
   ↓
4. 查看所有任务的进度
   - 5个任务同时进行
   - 每个显示独立进度
   ↓
5. 等待所有任务完成
   ↓
6. 统一查看和管理
   ↓
7. 批量下载或分享
```

---

## 🎓 高级技巧

### 提示词优化

**使用形容词**:
```
基础: "一朵花"
优化: "一朵盛开的粉色玫瑰花，花瓣上有晶莹的露珠"
```

**添加动态描述**:
```
基础: "树林"
优化: "风吹过树林，树叶沙沙作响，光影斑驳"
```

**指定镜头和角度**:
```
"俯视角度拍摄"
"近景特写"
"广角镜头"
"缓慢推进镜头"
```

### API性能优化

**并发控制**:
```typescript
// 限制同时进行的任务数量
const MAX_CONCURRENT = 3;
const queue = [];

async function generateWithQueue(prompt, model) {
  if (queue.length >= MAX_CONCURRENT) {
    await Promise.race(queue);
  }
  
  const task = generateVideoFromText(prompt, model);
  queue.push(task);
  
  task.finally(() => {
    const index = queue.indexOf(task);
    queue.splice(index, 1);
  });
  
  return task;
}
```

**缓存结果**:
```typescript
const cache = new Map();

async function getCachedVideo(videoId) {
  if (cache.has(videoId)) {
    return cache.get(videoId);
  }
  
  const result = await getVideoStatus(videoId);
  
  if (result.success && result.data.status === 'success') {
    cache.set(videoId, result);
  }
  
  return result;
}
```

---

## 🚀 快速命令参考

### 常用操作

| 操作 | 快捷方式 |
|------|---------|
| 打开工作室 | 点击底部中间按钮 |
| 生成AI视频 | 工作室 → 第一个卡片 |
| 图片转视频 | 工作室 → 第二个卡片 |
| 查看资产 | 底部"资产"Tab |
| 刷新进度 | 资产页右上角"刷新" |
| 播放视频 | 点击视频卡片 |

### API快速调用

```typescript
// 1. 快速生成视频
generateVideoFromText('提示词', 'sora2-portrait-15s');

// 2. 图片转视频
generateVideoFromImageFile(file, '提示词', 'sora2-portrait-15s');

// 3. 查询状态
getVideoStatus('video_id');

// 4. 获取所有视频
getLocalVideos();
```

---

## 📞 需要帮助？

- **查看API文档**: `/API_DOCUMENTATION.md`
- **查看快速开始**: `/QUICK_START.md`
- **查看集成指南**: `/API_INTEGRATION_GUIDE.md`
- **查看文档导航**: `/DOCS_INDEX.md`

---

**🎉 开始创作您的精彩视频作品吧！** 🚀✨
